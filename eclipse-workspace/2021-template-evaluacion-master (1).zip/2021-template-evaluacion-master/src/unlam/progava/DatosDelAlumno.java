package unlam.progava;

public class DatosDelAlumno {

	public static String nombres() {
		throw new RuntimeException("cambiame");
	}

	public static String apellidos() {
		throw new RuntimeException("cambiame");
	}
	
	public static int documento() {
		throw new RuntimeException("cambiame");
	}
}
