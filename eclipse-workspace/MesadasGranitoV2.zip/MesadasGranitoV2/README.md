# Ejemplo de resolución

Supondremos que la consigna pide realizar lo siguiente:

Escriba un algoritmo que totalice la suma de valores suministrados mediante un archivo de entrada, cuya primera línea especifica la cantidad de valores que siguen. Ejemplo:

00.in

```
4
1
3
5
7
```

00.out

```
16
```

Este respoitorio demuestra cómo utilizar la estructura suministrada para resolverlo.
