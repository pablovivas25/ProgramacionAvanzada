package conflictoentrereinas;

public class Reina {
	private int posX;
	private int posY;
	
	public Reina(int posX, int posY) {
		super();
		this.posX = posX;
		this.posY = posY;
	}

	public int getPosX() {
		return posX;
	}

	public int getPosY() {
		return posY;
	};
	
	
}
